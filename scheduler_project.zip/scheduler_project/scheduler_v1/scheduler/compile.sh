#!/bin/sh

g++ -std=c++20 -o scheduler $1 -lboost_system
